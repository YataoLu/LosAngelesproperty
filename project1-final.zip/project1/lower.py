#!/usr/bin/env python
"""
@author: Yataolu
"""

"""
A filter that have a functin of  tr '[:upper:]' '[:lower:]'.
"""

import fileinput


def process(line):
    """For each line of input, this command can transfer upper to lower"""
    print(line.lower())


for line in fileinput.input():
    process(line)
