#!/usr/bin/env python

"""
A filter that space each word.
"""

import fileinput


def process(line):
    """For each line of input, add space into each word."""
    print(line.strip())


for line in fileinput.input():
    process(line)
